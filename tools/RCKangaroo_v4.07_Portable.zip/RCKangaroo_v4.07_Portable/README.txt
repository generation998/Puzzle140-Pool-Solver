RCKangaroo v4.07 - portable folder
==================================

Copy this WHOLE folder to the other PC and run the .bat from inside it.
Do not move the .exe out on its own - it looks for the DLL and the CUBIN
folder next to itself.

Contents
--------
  RCKangaroo_v4.07.exe        the solver (unchanged, byte-for-byte)
  cudart64_12.dll             CUDA 12.8 runtime - this is what was missing
  CUBIN\kernel_sm89.cubin     turbo kernel, Ada / RTX 40xx
  CUBIN\kernel_sm120.cubin    turbo kernel, Blackwell / RTX 50xx
  Start J134 R139 DP30.bat    the f140 launch command

What the exe actually needs
---------------------------
Its import table lists exactly three libraries:
  cudart64_12.dll   -> included here
  nvcuda.dll        -> installed by the NVIDIA GPU driver, cannot be shipped
  KERNEL32.dll      -> part of Windows
The C++ runtime is linked statically, so no Visual C++ redistributable is
needed. Nothing else has to be installed.

If it still will not start
--------------------------
"nvcuda.dll was not found"  -> that PC has no NVIDIA driver. Install the
   current driver from nvidia.com. The CUDA Toolkit is NOT required.
"CUDA driver version is insufficient" -> driver too old for CUDA 12.
   Update the driver (R525 or newer).
"No GPUs found" -> the card is not CUDA-capable, or the driver is broken.

Notes
-----
- Without a matching CUBIN the program falls back to its built-in kernel;
  it still works, just slower on 40xx / 50xx cards.
- Cards older than SM 89 automatically use the legacy kernel.
- Running the same -checkpoints handle on a second PC is fine: the machine
  hash in the output filename is derived from the GPU UUIDs, so the two
  PCs write to different files and nothing is overwritten.
- PROGRESS\*.BIN is per-machine crash-recovery state. Do not copy it
  between PCs and do not send it to the pool.

cudart64_12.dll was taken from the CUDA 12.8 toolkit installed on this
machine (NVIDIA redistributable, version 12.8.57, 573,952 bytes).
